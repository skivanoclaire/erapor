@extends('layouts.app')
@section('title', 'Edit Siswa')
@section('content')
    <form method="POST" action="{{ route('students.update', $student) }}" class="bg-white rounded-lg shadow p-4 max-w-3xl">
        @csrf @method('PUT')
        <h2 class="font-semibold mb-4">Edit Siswa</h2>
        <div class="grid sm:grid-cols-2 gap-4">
            <label class="text-sm">Sekolah
                <select name="school_id" class="mt-1 w-full border rounded px-3 py-2">
                    @foreach ($schools as $id => $n)
                        <option value="{{ $id }}" @selected($student->school_id == $id)>{{ $n }}</option>
                    @endforeach
                </select>
            </label>
            <label class="text-sm">Kelas
                <select name="class_id" class="mt-1 w-full border rounded px-3 py-2">
                    <option value="">-</option>
                    @foreach ($classes as $id => $n)
                        <option value="{{ $id }}" @selected($student->class_id == $id)>{{ $n }}</option>
                    @endforeach
                </select>
            </label>
            <label class="text-sm">NISN <input name="nisn" value="{{ old('nisn', $student->nisn) }}"
                    class="mt-1 w-full border rounded px-3 py-2"></label>
            <label class="text-sm">Nama <input name="nama" value="{{ old('nama', $student->nama) }}"
                    class="mt-1 w-full border rounded px-3 py-2"></label>
            <label class="text-sm">JK
                <select name="jk" class="mt-1 w-full border rounded px-3 py-2">
                    <option value="L" @selected($student->jk === 'L')>L</option>
                    <option value="P" @selected($student->jk === 'P')>P</option>
                </select>
            </label>
            <label class="text-sm">Tanggal Lahir <input type="date" name="tanggal_lahir"
                    value="{{ old('tanggal_lahir', $student->tanggal_lahir) }}"
                    class="mt-1 w-full border rounded px-3 py-2"></label>
            <label class="text-sm">No. Rumah <input name="nomor_rumah"
                    value="{{ old('nomor_rumah', $student->nomor_rumah) }}"
                    class="mt-1 w-full border rounded px-3 py-2"></label>
            <label class="text-sm">No. HP <input name="nomor_hp" value="{{ old('nomor_hp', $student->nomor_hp) }}"
                    class="mt-1 w-full border rounded px-3 py-2"></label>
        </div>
        <div class="mt-4">
            <button class="rounded bg-blue-600 text-white px-4 py-2">Simpan</button>
            <a href="{{ route('students.index') }}" class="px-4 py-2 rounded border">Batal</a>
        </div>
    </form>
@endsection
