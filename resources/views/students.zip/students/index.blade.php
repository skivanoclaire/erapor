@extends('layouts.app')
@section('title', 'Siswa')
@section('content')
    <div class="bg-white rounded-lg shadow p-4">
        <div class="flex items-center justify-between mb-4">
            <h2 class="font-semibold">Siswa</h2>
            <a href="{{ route('students.create') }}" class="px-3 py-2 rounded bg-blue-600 text-white text-sm">Tambah</a>
        </div>

        <form method="GET" class="mb-3 flex gap-2">
            <input name="q" value="{{ $q }}" placeholder="Cari nama/NISN..."
                class="border rounded px-3 py-2 w-full sm:w-64">
            <select name="class_id" class="border rounded px-3 py-2">
                <option value="">Semua Kelas</option>
                @foreach ($classes as $id => $n)
                    <option value="{{ $id }}" @selected($classId == $id)>{{ $n }}</option>
                @endforeach
            </select>
            <button class="px-3 py-2 border rounded">Filter</button>
        </form>

        <div class="overflow-x-auto">
            <table class="min-w-full text-sm">
                <thead class="text-left text-slate-500">
                    <tr>
                        <th>NISN</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>JK</th>
                        <th class="text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($students as $s)
                        <tr class="border-t">
                            <td class="py-2">{{ $s->nisn }}</td>
                            <td class="py-2">{{ $s->nama }}</td>
                            <td class="py-2">{{ $s->class->nama_kelas ?? '-' }}</td>
                            <td class="py-2">{{ $s->jk }}</td>
                            <td class="py-2 text-right">
                                <a href="{{ route('students.edit', $s) }}"
                                    class="px-2 py-1 border rounded hover:bg-slate-50">Edit</a>
                                <form method="POST" action="{{ route('students.destroy', $s) }}" class="inline"
                                    onsubmit="return confirm('Hapus siswa?')">
                                    @csrf @method('DELETE')
                                    <button class="px-2 py-1 rounded bg-rose-600 text-white">Hapus</button>
                                </form>
                            </td>

                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <div class="mt-3">{{ $students->links() }}</div>
    </div>
@endsection
