<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SchoolHead extends Model
{
    protected $fillable = ['school_id','nip','gelar_depan','nama','gelar_belakang'];
    public function school(){ return $this->belongsTo(School::class); }
}
