<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    protected $fillable = [
        'school_id','nisn','nama','class_id','jk',
        'tanggal_lahir','nomor_rumah','nomor_hp'
    ];

    public function school(){ return $this->belongsTo(School::class); }
    public function class(){ return $this->belongsTo(SchoolClass::class, 'class_id'); }
}
