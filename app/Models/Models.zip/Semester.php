<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Semester extends Model
{
    protected $fillable = ['school_id','tahun_ajaran','semester','status'];

    public function school(){ return $this->belongsTo(School::class); }

    public function scopeActive($q){ return $q->where('status','berjalan'); }
}
