<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class ExtracurricularAssessment extends Model
{
    protected $fillable = [
        'extracurricular_id','semester_id','student_id',
        'mid_grade','mid_description','final_grade','final_description'
    ];
}
